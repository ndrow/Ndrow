<?php
/* Theme Loader untuk React Build */

function my_react_theme_scripts() {
  $theme_dir = get_stylesheet_directory_uri();

  // enqueue CSS
  wp_enqueue_style('react-app', $theme_dir . '/assets/index-DazjgSg2.css');

  // enqueue JS
  wp_enqueue_script('react-app', $theme_dir . '/assets/index-BEMaUPcw.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'my_react_theme_scripts');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <div id="root"></div>
  <?php wp_footer(); ?>
</body>
</html>